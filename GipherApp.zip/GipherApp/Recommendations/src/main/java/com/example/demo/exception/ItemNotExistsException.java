package com.example.demo.exception;

public class ItemNotExistsException extends Exception {
	public ItemNotExistsException() {}

}
