package com.example.demo.exception;

public class ItemAlreadyExistsException  extends Exception {

	public ItemAlreadyExistsException()
	{
		super();
	}
	
}
