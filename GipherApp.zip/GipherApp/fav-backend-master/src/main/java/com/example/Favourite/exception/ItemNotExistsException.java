package com.example.Favourite.exception;

public class ItemNotExistsException extends Exception {
	public ItemNotExistsException() {}

}
