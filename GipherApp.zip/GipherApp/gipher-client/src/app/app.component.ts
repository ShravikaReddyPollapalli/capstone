import { Component, OnDestroy, OnInit } from '@angular/core';
import { GipherService } from './gipher.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
//   title = 'gipher';
//   gifs : any = [];
//   name;
//   error;
//   results: any[];
//   totalRecords: string;
//   page:Number=1;
//   constructor(private gipherService: GipherService){ }
 
//  ngOnInit() {
//    console.log("this is app component")
//    this.destroyMe();
//  }
//  destroyMe() {
//    this.gipherService.getGifs(this.name) 
//    .subscribe((data: any) => {
//      console.log(data);
//      this.gifs = data;
//      console.log(data);
//    })
//  }

//  ngOnDestroy(){
//    console.log("this is destroy")
//  }
}
