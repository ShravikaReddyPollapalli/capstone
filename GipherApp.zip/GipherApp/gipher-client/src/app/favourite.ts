

export class Favourite{
    id: string;
    username: string;
    title:string;
    url:string;
   
}
