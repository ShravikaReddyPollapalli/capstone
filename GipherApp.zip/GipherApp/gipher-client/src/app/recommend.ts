

export class Recommend{
    id: string;
    recommend : boolean;
    url:string;
   
}


