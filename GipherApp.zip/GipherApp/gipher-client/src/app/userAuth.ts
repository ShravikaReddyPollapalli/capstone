export class UserAuth{
   userName: string;
   password: string;
}
// User Authentication model class