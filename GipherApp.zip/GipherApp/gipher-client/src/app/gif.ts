export class Gif{
    id: string;
    username: string;
    title:string;
    url:string;
   
}