//encoding
//EncodeURI
var uri = "mytest.asp?name=shdr&car=dghs";
var res = encodeURI(uri);
console.log('the encoded uri',res);

//encodeURIComponent
console.log('the encoded uri component' ,encodeURIComponent(res));

//decoding
//decodeURI (used to decode a URI)
//decodingURI component
//return value is a string

var uri = "my name.asp.?user=name=nikith&password=qwerty";
var enco = encodeURI(uri);
console.log('the encoded uri is',enco);
var deco = decodeURI(enco);
console.log('the decoded uri is',deco);



//decodeURIComponent
console.log('the new encoded uri component',encodeURIComponent(res));
console.log('the new decoded uri component',decodeURIComponent(res));
