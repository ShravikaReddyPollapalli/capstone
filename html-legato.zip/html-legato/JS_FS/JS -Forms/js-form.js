
        //Form validation code will come here
     
        function validate() {
            if (document.myForm.Name.value == "")
             {
                alert("please provide your name");
                document.myForm.Name.focus();
                return false;
            }
            if (document.myForm.Email.value == "") {
                alert("please provide your mail");
                document.myForm.Email.focus();
                return false;
            }
            if (document.myForm.Zip.value == "" || isNaN(document.myForm.Zip.value) || document.myForm.Zip.value.length != 5) {
                alert("please provide a zip in the format #####");
                document.myForm.Zip.focus();
                return false;
            }
            if (document.myForm.Country.value == "-1") {
                alert("please provide your country");
                document.myForm.Country.focus();
                return false;
            }
            return true;
        }

 