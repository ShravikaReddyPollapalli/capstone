/*//using getElementById

//var can be used multiple times with same name
//let keyword can be used only once
//const is constant we cannot change
//document.body.style.backgroundColor = 'blue';//to change the background color of browser


let pElement = document.getElementById('demo');


//dont use console.log(pElemnent)
//once we get the element then only access the text context


let pText = pElement.textContent;
console.log('the ptext value is',pText);//hello

// //the old value of pElement will be overridden
console.log('the pelement is',pElement);//<p id="demo">hello</p>

//adding another element
pElement.textContent = "hi everyone";
console.log('After adding the plement is:',pElement.textContent);//hi everyone
*/


//using getElementsByClassName

var pElement2 = document.getElementsByClassName('test')[0];
console.log(pElement2);
let pText2 = pElement2.textContent;
console.log(pText2);

//using tagName

var pElement3=document.getElementsByTagName('h1');
console.log(pElement3);
let pText3=pElement3.textContent;
console.log(pText3);

//using name

var pElement4=document.getElementsByName('male');
console.log(pElement4);
let pText4=pElement4.textContent;
console.log(pText4);

//querySelector

var pElement5=document.querySelector('.test');
console.log(pElement5);
let pText5=pElement5.textContent;
console.log(pText5);


//querySelectorAll
var pElement6=document.querySelectorAll('.test');
console.log(pElement6);
let pText6=pElement6.textContent;
console.log(pText6);

