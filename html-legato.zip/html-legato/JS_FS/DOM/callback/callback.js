function notification(sms,email){
    console.log("process starts");
    sms();
    email();
}
notification(function (){
    alert("send sms");
},function() {
    alert("send email");
});
console.log('end process');