//on keydown event

const elekeydown = document.getElementById('one');
elekeydown.onkeydown = function(){
    console.log('triggered');
}


//on keyUp event

//writing events using the addEventListener
const elekeyup = document.getElementById('two')
const bind = document.createElement('p');
elekeyup.addEventListener('Keyup',function() {
    bind.textContent = elekeyup.Value; //.value is used to get the value

    //use value when taking input from user
    console.log(elekeyup.value);
    console.log("key up event");

    //to print the values in browser as well
    document.body.appendChild(bind);
})

//two way binding
let ele = document.createElement('p');
const third = document.getElementById('two way');
third.addEventListener('keyup',function (){
    ele.textContent = third.value;
    document.body.appendChild(ele);
})