function greet(){
    alert('hi');
}





//to create element multiples times
function elementCreation(){
    let element = document.createElement("p");
    element.textContent="priya";
    document.body.appendChild(element);
}

//to create element only once
let element = document.createElement("p");
document.body.appendChild(element);
function elementReation(){
     element.textContent="priya";
    }

    //to print data in console by clicking on a text
    function showData(){
        let ele = document.getElementById("show");
        console.log(ele.textContent);
    }