//unordered list
const ulElement =  document.createElement('ul')
ulElement.textContent="lipsticks"

const li1Element = document.createElement('li')
li1Element.textContent="Lakme"

const li2Element = document.createElement('li')
li2Element.textContent="Loreal"

ulElement.appendChild(li1Element);
ulElement.appendChild(li2Element);

console.log(ulElement);
// document.write(ulElement);



//adding to the body
document.body.appendChild(ulElement);




//ordered list
const olElement = document.createElement('ol')
olElement.textContent="cars"

const l1Element = document.createElement('li')
l1Element.textContent="audi"

const l2Element = document.createElement('li')
l2Element.textContent="Ferrari"

olElement.appendChild(l1Element);
olElement.appendChild(l2Element);

console.log(olElement);
// document.write(ulElement);

//adding to the body
document.body.appendChild(olElement);



//if we want to create multiple buttons with values without using button tag
//use createElement()
//from net
/*
  let i = a;
  let body = document.getElementsByTagName("body")[0];
  
  for (i; i <= 20; i++) {
    let button = document.createElement("button");
    button.innerHTML = 'Button '+i;
    body.appendChild(button);
    button.addEventListener ("click", function() {
      alert(this.innerHTML);
    });
  }*/

  //creating multiple buttons in dom with different names

  let ar = ['a','b','c','d','e','f','g','h','i','j'];

  function buttons(){
      for(let i=0;i<10;i++){
          let button = document.createElement("button");
          button.textContent=ar[i];
          document.body.appendChild(button);
      }
  }
  buttons();