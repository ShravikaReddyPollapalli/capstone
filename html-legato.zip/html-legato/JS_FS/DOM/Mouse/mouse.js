//calling events through html file

function addStyle(){
    const mouseele = document.getElementById('add');
    mouseele.className='addStyle';
}

function removeStyle(){
    const mouseout = document.getElementById('add');
    mouseout.className="removeStyle";
}

//calling event through js
const bElement=document.getElementById('one');
bElement.onclick = function (){
    alert('you clicked me!!');
}
 