(function () {
    let element =  document.getElementById("demo");
element.style.color='blue';
element.style.fontSize='30px';
element.style.backgroundColor="black";

//to add multiple css properties in javascript using a id and classname
//where you write multiplecss properties with different classname

let deco = document.getElementById('sam');
deco.className='add';
}());

//to add multiple class names we use claass list
let x=document.getElementById('test');
x.classList='add header';
