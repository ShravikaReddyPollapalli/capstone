//using the str.match()

//1)regular expression has flag g, it returns an array of all matches:
//let str1 = "we will,we will rock you we";
//alert(str1.match(/we/i));
//gi-all
//g-we
//i-we
//We,we (an array of 2 substrings that match) and
//i makes the regexp case insensitive

//eg:-2
// let strs = "We will , we will rock you a good song";
// let result =  strs.match(/we/i); //without flag g
// console.log('regexp result', result);
//alert(result[0]); //We (1st match)
//alert(result.length); //1
/*
//Details:
alert(result.index); // 0 position of the match
alert(result.input); //We will,we will rock you (source string)


//2) the method str.replace(regexp, replacement) replaces matches found using
//regexp in string str with replacement (all matches if theres flag g,otherwise
//only with the first one

//no flag g
alert("We will , we will".replace(/we/i, "i")); // I will ,we will


// with flag g
alert("we will, we will".replace(/we/gi,"I")); // I will, I will

*/

//Character class

//1)Character class without flag
let str3 = "+7(903)-123-45-67";
let regexp = /\d/;//digit class
alert(str3.match(/\d/));//7

// //with flag g : 
let str4 = "+7(903)-123-45-67";
let regexp1 = /\d/g;
alert(str4.match(/\d/g));
