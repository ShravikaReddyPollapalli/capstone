//control statements
//if
var i= 20;
if(i<15)
{
    document.write("20 is less than 15");
}

  //  document.write('it is not less than');



// if else statement
var i=20;
if(i<15)
 {
document.write("10 is less than 15");
}
else{
    document.write("is greater than")
}

//nested if

var i=20;
if(i==10)
{
    document.write("i is 10");
}
else if(i==15)
{
    document.write("i is 15");
}
else if(i==20)
{
    document.write("i is 20");
}
else{
    document.write("i is not present");
}