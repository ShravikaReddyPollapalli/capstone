//Anonomyous function
/*function()
{
    alert('im a no name function');
} ;*/

/*//anononmyous function with function expression
var message=function()
{
    alert('hello world');
}
message();

//naming function
function sample(){
    alert('im a named function');
}
sample();

//function expression
var test= function(){
    alert('this is function expression');
}
test();

//immediate invoke function
(function(){
    alert('immediate');
})
();

//immediate using document.write
(function(){
    document.write("shravika");
})();



//using console
(function() {
    console.log("im a immediate");
})();


//local variables
function show(){
    var message="hello";
    alert(message);
}
show();

//test
function show(){
    var message="hello";
}
alert(message);//message is not defined
show();*/
/*
//global variables
 var test= 'shravika';
 function showOutput(){
 var  msg  = "hello ,welcome " + test;
 alert(msg);
}
 showOutput();*/

/*
var userName = 'john';
function showMessage(){
    var userName="bob";//declaring a local variable
    var message='hello' +userName;//Bob
    alert(message);
}
showMessage();//the function will create and use its own username
alert(userName);//john unchanged,the function did not access the outer variables


//function with parameters

function sample(from,text) {
    alert(from + ":" + text);
}
sample("annie","welcome");

/*
//test
function checkAge(age) {
    if(age >= 18)  {
        return true;
    } else {
        return confirm('Do you have permission from your parents?');
    }
}
 
 var age = prompt('how old are u?',18);
 if( checkAge(age)) {
   alert( 'access granted');
 } else {
     alert( 'access denied');
 }*/
 
 //function closure
 function outer(){
     var out="im a outer function";
     document.write(out + "<br/>");

     function inner(){
         var inn="im a inner function";
         document.write(inn +"<br/>");
     }
     return inner();
 }
outer();                                                                     


console.log("tst");