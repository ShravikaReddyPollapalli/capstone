//variable hoisting
//eg:1
var name;//first we need to declare the varibale then we need to call
console.log(name);
name = 'hello world';
/*
//function hoisting using local variable
hoist();
function hoist(){
    console.log(message);//undefined
    var message = 'javascript is very easy';
    console.log(message);//js is very easy
}*/