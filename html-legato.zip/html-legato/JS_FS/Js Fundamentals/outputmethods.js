//alert('hi');

var isBoss=confirm('confirm message');
alert(isBoss);

//prompt('im a prompt');

//console.log('im a console msg');

//document.write('im a document msg');