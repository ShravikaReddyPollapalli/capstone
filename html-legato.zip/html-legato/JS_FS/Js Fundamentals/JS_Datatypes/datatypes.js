/*//primitive datatypes

//number
var a=10.1;

console.log('the 10 is',typeof a);//the return type will be number

//string
var str="qspiders",
    str2='jspiders';

console.log('the qspiders is ',typeof str);//string
console.log('the jspiders is ',typeof str);//string
console.log(`welcome to ${str}`);//welcome to qspiders

//boolean
var x=true;
console.log('the boolean type is' ,typeof x);

var isGreater = 4>1;
alert(isGreater);

//test
var name="rina";
alert(`hello ${1}`);
alert(`hello ${"name"}`);
alert(`hello ${name}`);

//null
var x1=null;
console.log('the value is',typeof x1);

//undefined
var s1;
var s2='qwert';
alert(s2);

var s1;
var s2='asdfg';
console.log()

var s1;
alert(s1);

var s2='qwerrty';
s2=undefined;
alert(s2);*/
console.log("hi");

var x ;
x = 16;
x = 'shra';
//console.log(x);
//alert(x);
//document.write(x);
document.getElementById("demo").innerHTML = x;