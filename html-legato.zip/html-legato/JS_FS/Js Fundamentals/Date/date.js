var dt = new Date();
console.log(dt);

var cd = new Date(2019,11,25);//current date
console.log(cd);

//date object methods
var todaysdate = new Date();
console.log('todays date is' ,todaysdate);
console.log('day' ,todaysdate.getDay());
console.log('day' ,todaysdate.getFullYear());
console.log('day' ,todaysdate.getDate());
console.log('day' ,todaysdate.getHours());


//time delays
//eg1
setTimeout(function(){
    var date = new Date().toLocaleTimeString();
    var x = document.getElementById('demo');
    x.innerHTML = date;
},5000);


//eg2
setTimeout(function(){
console.log('hello people');
},2000);

//setInterval
setInterval(function(){
    var date = new Date().toLocaleTimeString();
    var x= document.getElementById('demo');
    x.innerHTML=date;
},1000);