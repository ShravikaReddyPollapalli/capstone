//for loop
var i;
for(i=0;i<10;i++){
    document.write('hello'+'<br/>');
}

//while loop
var x=1;
while(x<=4)
{
    document.write('value of x:' + x +'<br/>');
    x++;
    
}


//do while
var x =21;
do{
    document.write('value of x:' + x + '<br/>');
    x++;
}while(x < 20);

//for of loop
var num=[1,2,3];
for(var test of num){
    console.log('show the numbers',test);
}

//for in loop(with arrays)
var fruits = ['mango' ,'apple','dhuwjdhd'];
for(var test in fruits){
    console.log('the for in values are',test); //it stores only index
    console.log(fruits[test]);//it stores both index and value
}

//for in loop(with objects)
var person = {
    name: 'priyanka',
    age:18,
    company: 'testyantra'
}
for(var key in person){
    console.log("key is",key); //it retrieves the key value

    //it retrieves both the key and values
    console.log('person is',person[key]);
}

