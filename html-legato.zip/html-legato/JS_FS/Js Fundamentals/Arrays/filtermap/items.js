//its a combination of array,arrows,objects
//array inside multiple object

//to check the flow of execution we use debugger
//is breakpoint and debugger are same?


var items = [
    {
        id:01,
        name:"lipstick",
        price:800
    },
    {
        id:02,
        name:"shampoo",
        price:500
    },
    {
        id:03,
        name:"liner",
        price:300
    },
    {
         id:04,
         name:"mac",
         price:900
    }
]

// console.log(items[0]);
// console.log(items[1]);
// console.log(items[2]);
// console.log(items[3]);

//instead of use for of

for(var list of items){
    console.log(list.id);
}

var afterfilter = items.filter(items => {return items.price > 500});
console.log('after filter',afterfilter);

//map wrt debugging in source file
var mappedlist = items.map(function(item) {
    debugger //it helps to stop line 45

    console.log(item)
    var v = {
        id:item.id,
        name:item.name,
        price:item.price + 50
    }
    return console.log(v);
})

//debugger
// console.log(v);