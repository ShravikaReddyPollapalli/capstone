//filter method

var numbers = [100,200,300,400];
var afterfilter = numbers.filter(function(value,index){
    if(value > 200)
   {
       return true;
   } 
   else{
       return false;
   }
})
console.log('before filter',numbers);//100 200 300 400
console.log('after filter',afterfilter);//300 400



//map method
var numbers = [100,200,300,400];
var mappednumbers = numbers.map(function(val,index){
    val = val + 50;
    return val;
})
console.log("before mapping" , numbers);//100 200 300 400
console.log("after mapping" , mappednumbers);//150 250 350 450


//using arrow function (single line)
//js engine adds the return statement

var valueafterFilter = numbers.filter(val => val>200);
console.log(valueafterFilter);