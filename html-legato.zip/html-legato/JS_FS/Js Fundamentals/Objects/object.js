//object

var user = {
    name : 'shra',
    age : 21,
    place : 'hyd'
}
//all details of user
console.log(user);

//retrieving the details individually
console.log('the age is',user.age);
console.log('the name is',user.name);
console.log('the place is',user.place);

//to add the property
user.designation = 'java developer';
console.log('after adding new value' ,user);

//to delete the property
delete user.age;
console.log('after deleting',user);

//var objectName = new Dress();//anotherway in js
//let objectName = new Dress("passing string");//anotherway in es6
//function Dress(receivingstring){
   // this.receivingstring=receivingstring;
//}