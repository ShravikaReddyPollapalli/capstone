var arr = ['nodejs' ,
true ,
123 ,
{name : 'shra',age : 21},
function(){
    alert('dgf');
}];


//calling the object values
alert(arr[3].name);

//to call the functions(calling the anonomyous function)
arr[4]();

