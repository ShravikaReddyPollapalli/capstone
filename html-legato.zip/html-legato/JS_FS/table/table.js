const ta =  document.createElement('table')
ta.textContent="lipsticks"

const head = document.createElement('th')
head.textContent="Lakme"

const data = document.createElement('td')
data.textContent="Loreal"

ta.appendChild(head);
th.appendChild(data);

console.log(ta);
// document.write(ulElement);