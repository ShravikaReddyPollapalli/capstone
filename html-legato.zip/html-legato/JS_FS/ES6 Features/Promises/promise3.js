//when evr we want to call all the promises,for that we pass variables we use promise.all()
