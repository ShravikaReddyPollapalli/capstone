//promises are very important
const myPromise = new Promise(function(resolve,reject) { //Promise is constructor
    if(50>100) {
         resolve("its true");
        // reject("its false");
    } 
    else {
         reject("its false");
        //   resolve("its true");
    }
});
myPromise

//it takes the value of resolve
.then(function( ) {
    console.log(success)
})

//it takes the value of reject
.catch(function(error) {
    console.log(error);
});