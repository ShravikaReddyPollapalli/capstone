console.log("JS startd");
//if we have bunch of data we use promise
const myPromise1 = new  Promise((resolve, reject) => {
    if (20 > 10) {
        const data = [100,200,300,400];
        resolve(data);
    }
    else {
        reject("failed to fetch the data")
    }
});
myPromise1
 .then(data => {
     console.log("data is ", data);
     const filterData = data.filter(val => val > 2000);
     return filterData;
 })
 .then(filterData => console.log("filtered Data", filterData))
 .catch(error => console.log("error is" , console.log));

 //what if we have multiple folders,we use promise.race() promise.all()