var data = [4,5,2,6,8,4,2,1];
var set1 =new Set(data);
console.log('data length', data.length);// 8
console.log('set size',set1.size); //6

//eg:2
let arr= ['white','black','red','purple','green','indigo','blue'];
let set = new Set(arr);
console.log('after add method',set.add('pink'));
console.log('after has method',set.has('purple'));
console.log('after delete method',set.delete('red'));
console.log('after deleting the has method',set.has('pink'));
