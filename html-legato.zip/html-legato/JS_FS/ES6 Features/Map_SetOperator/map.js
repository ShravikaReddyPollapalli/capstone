//map new map object values can be object,values can be same,keys cannot be same
//set and get () are used

//eg1:

var course = new Map();
course.set("react",{ descrip: "UI"}, "Jest" ,{descrip: "testing"});

console.log("the courses are",course);

//to get the values wrong way
//these cant be used i.e (.) notation
///console.log(course.react); //undefined

//to get the values. Correct way
console.log(course.get("react"));


//eg2:
//map with parameters (with(set))

//passing an array inside map constructor
var details = new Map([
    [new Date(), "today"],
    ["item",[1,2,3]]
]);

console.log(details.size);//2
details.forEach(function(item) {
    console.log(item)
});