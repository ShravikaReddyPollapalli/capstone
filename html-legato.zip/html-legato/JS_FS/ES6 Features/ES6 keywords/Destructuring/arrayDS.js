const rgb = [255,200,0];

//array destructuring
const [red,green, blue] = rgb;
console.log(`R: ${red}, G: ${green}, B: ${blue}`);