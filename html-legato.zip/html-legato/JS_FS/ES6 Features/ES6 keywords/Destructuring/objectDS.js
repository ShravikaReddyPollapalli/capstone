// we use object literal on the LHS of an assignment operator

const student = {
    fname : 'smith',
    lname : 'shine'
};

//object DS:
const { fname,lname } = student;
console.log(fname ,lname);

//previously we have done printed with individual values
//eg2
let optiions = {
    title : "menu",
    width : 100,
    height : 200
};
let {title , width , height} = optiions;

alert(title); //menu
alert(width); //100
alert(height); //200


//we can change the order the let
// let {height, width, title}={title: "menu" , height:200,width:100}