// var x= 5+10;
// console.log(x);//15

let x ;
let name = 'mukthi';
let names = 'jaya';
console.log(name);//mukhti

//in let re-decalaration is not possible
//re-initialization is possible

// //
let a = 3;
a = 11;//works same as var
console.log(a);

let x1 = 10;
if(x1){
    let x1 = 4;
    console.log(x1); //4
}
console.log(x1); //10



// const variable
const name1 = 'manu';
//name1 = 'mayanak'; //will give error
console.log(name1);
