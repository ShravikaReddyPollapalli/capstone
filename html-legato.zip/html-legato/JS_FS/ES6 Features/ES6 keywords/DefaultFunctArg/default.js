// function with no arguments
function my(num){
    console.log(num);
}
my();//undefined


// // function with default parameter
function myNumbers(num = 10){
    console.log(num);
}
myNumbers(); // had not passed any argument so default value is 10
myNumbers(undefined); //instead of undefined it takes the num as 10
myNumbers(20); //now the value passed was 20 so it is 20



//eg2