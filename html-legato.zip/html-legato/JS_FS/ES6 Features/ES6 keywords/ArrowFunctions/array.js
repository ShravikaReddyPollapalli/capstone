//old way or longhand
// function say(name){
//     console.log("hello",name);
// }
// say(prompt('enter ur name'));

//
setTimeout(function(){
    console.log("loaded")
},2000);
//this is anonomyous function  because there is no name for function// this is not immediate invoke function

// // 
// var list = ['soc','botany','bio'];
// list.forEach(function(item){
//     console.log(item);
// })


// //Arrow Functions:
// say = name => console.log("hello",name);
// say(prompt('enter ur name'));

// setTimeout(()=> console.log('loaded'),2000);

// var list = ['soc','bot','bio'];
// list.forEach(item => console.log(item));