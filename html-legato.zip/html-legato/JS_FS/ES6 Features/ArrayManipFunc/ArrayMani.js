//Array.of()
let prices = Array.of(5000);
console.log(prices.length); //1

//Array.from() and pass in prices as the first argument
//and an arrow function as the second argument
//it creates new instance of array
let price = [500,600,650];
let taxed = Array.from(price, price => price * 1.05);
console.log(taxed); //[525,630,682.5]

//Array.find()
//Array.find() is another new function added to arrays in ES6

let price2 = [500,600,700,800,900,1000];
let result = price2.find(price => price > 777);
console.log(result); //800
 // this array.find() returns  the value of the first element in an array that passes a given test

 let price3 = [500,600,700,800,900,100]


 //Array.findIndex()
 //the Array.findIndex() function which works in a similar
 //way but instead of returning the value, it returns the index
 //way but instead of returning the value,it returns the index
 let price4 = [500,600,700,800,900,1000,1500];
 let result1 = price4.findIndex(function(price) {
     return price == this;
 }, 1000);
 console.log(result1); //5



 //Array.every()
 //array.every(callback[,thisobject]);
 //callback function to test for each element
 //this object - object to use as this when exciting callback
 //returns true if every element in this array satisfies
 //the provided  testing function.

 //eg:1
 function isBigEnough(element,index,array) {
     return (element >= 10);
 }
 var passed = [12,11,13,104,115].every(isBigEnough);
 console.log("test value : " + passed);//true

 //eg2:
 function test(element,index,array) {
     return index < 4;
 }
 document.writeln([21,32,2,43].every(test));//true
 document.writeln([32,21,2,43,35].every(test));//false
    
 //Array.some()
 //This method checks if an item (one or more) in an array pass
//the specified condition and return true if passed,else false
//array.some(callback[,thisObject]);

//callback - function to test for each element.
//thisObject - object to use as this when executing callback
//if some element passes the test,then it returns true,otherwise false
console.log([1,2,3].some(function(x) { return x > 5;}))  // => false : no ele are > 5
console.log([1,2,3].some(function(x) { return x > 5;})) //=> true : some elements 