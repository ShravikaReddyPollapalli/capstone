//spread operators with array
const setone = ["aa" ,"bb","cc"];
const settwo = ["one", "two","three"];
const allset = [...setone, ...settwo];
console.log(allset);//aa bb cc one two three


//spread operator with object
const person = {
    name: "priya",
    age: 35,
    place: "blore"
};

//creating a copy of object
const copyOfPrsn = { ...person };

person.name = "sundari";
console.log("the person list is",person);
console.log(" the copy of person",copyOfPrsn);

console.log("=============");

//adding two objects
const teacher = {
    name: "rena",
    age: 30,
    color: "pink",
    subjects: ["social" ,"english"]
};
const address =   {
    city: "blore",
    pincode: "56009",
    landmark: "btm"
};

//adding extra keys and value for the created objects
const teacherDetails = {...teacher, ...address};
console.log("teacher with address", teacherDetails);

const teacherWithPhone = {
    ...teacher,
    phone: 123456899,
    married: false,
    getName: function() {
        return this.name;
    }
};

console.log("teacher with phone number", teacherWithPhone);