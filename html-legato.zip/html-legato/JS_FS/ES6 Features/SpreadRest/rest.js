//never use const in for loop because there is no re-assignment  in const

function sum(...nums) {
    let total = 0;
    for (let i = 0;i < nums.length;i++) {
        total += nums[i];
    }
    return total;
}
const val = sum(100,200);
console.log("the sum of two values is", val);

const val11 = sum(100,200,240);
console.log("the sum of three values is", val11);


















//rest operator example 2 (rest should be used at last)
function printAnimals(ani1, ani2, ...animals) {
    console.log("animal one", ani1);
    console.log("animal two", ani2);


//we
for(let i =0;i < animals.length;i++) {
    console.log(animals[i]);
}
}
printAnimals("lion","tiger","cow","dog");
