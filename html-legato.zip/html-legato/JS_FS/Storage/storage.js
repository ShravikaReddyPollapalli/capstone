//to set the values for the local storage

localStorage.setItem('role','trainer');
localStorage.setItem('email','shra@gmail.com');
localStorage.setItem('place','bglore');
localStorage.setItem('company','cg');

//to get the items from local storage

const emails = localStorage.getItem('email');
console.log('the email id is',emails);

const rol = localStorage.getItem('role');
console.log('the role is',rol);



//to remove the item from the localstorage
localStorage.removeItem('place');

//to clear the localStorage
//localStorage.clear();