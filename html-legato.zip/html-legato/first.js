console.log("my first js code");

var example = 2.4;
console.log(example);
console.log(parseInt(example, 10));
console.log(parseFloat(example));
console.log(example.toString());
console.log(example.toFixed());
console.log(example.toPrecision(3));