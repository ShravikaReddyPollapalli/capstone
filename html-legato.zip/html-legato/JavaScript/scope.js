var word = "Hello";
var animals = ["dog", "elephant", "lion"];

greeter(word, animals);

function greeter(str, arr) {
    var counter;
    for(counter = 0; counter <arr.length;counter++) {
        console.log(str + " " +arr[counter]);
    }
}


//var statements limit variables to the local scope.
function example() {
    var local = "only available inside example()"; // with var
    global = "Available anywhere once executed"; //without var
}

// console.log(local); //error
// console.log(global); //error
// example();
// console.log(local); //error
// console.log(global); //also available anywhere)


//variable scope is inherited one way
//functions inherit variables in the parent scope

var phrase = "always avaialble";
function example() {
    var local = "only inside";
    console.log(phrase);
    console.log(local);
}
// example();   //always available  //only inside
console.log(phrase);  //always avaialble
// console.log(local);  error




//hoisting
function predefined() {
    var before = 5;
    var after = 10;
    console.log(before + after);
}
function undefinedAfter() {
    var before = 5;
    return(before + after);
    var after = 10;
}
function undeclaredAfter() {
    var before = 5;
    console.log(before+after);
}
predefined();
console.log(undefinedAfter());
// undeclaredAfter();


//global
var count = 5;
console.log(count);
console.log(window.count); 
window.count = 10;
console.log(count);

var count = 5;
thousands(50);
function thousands(price) {
    count = 1000 * price;
    return(count);
}
for(count = 0;count <6; count++) {
//do something
}
//a bunch of other code

console.log(count);

//ways to isolate variable scope
//to keep safe from global scope
//keep local variables out of the global object i.e.,functions,iife,custom objects)
 //examples
   function thousands(price) {
       var count = 1000 * price;
   }
//IIFE
 (function() {
     var count;
     for(count = 0; count < 6;count++) {
         //do something six times
     }
 }()); //execute that function expression

 //local to a private object (less safe)
 var myApp = {};
 myApp.count = "Hello".length;
 console.log(count); //error
