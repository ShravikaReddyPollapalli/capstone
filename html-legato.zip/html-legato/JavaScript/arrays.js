var arr = ['java' ,'sql', 'react' ,'nodejs','jsp','webtech'];

//to display all the elements
console.log('the array elements are' , arr)

//to retrieve the array elements using index value
console.log('the element in index 3 is',arr[3]);

//to find the length of the array elements
console.log('the array length is ' ,arr.length);

//to replace a new element
console.log('replacing element is',arr[2]= 'Mongo db');
console.log('after replacing the new element',arr);

//adding the new element in an array
console.log('the new element is' ,arr[6]='Jquery');
console.log('After new element',arr);
console.log('new element of array',arr.length);

alert(Array.from("shra"));
    