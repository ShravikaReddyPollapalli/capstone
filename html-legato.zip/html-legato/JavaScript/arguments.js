var color = "red";
// showItem(color);
function showItem(item) {
    console.log(item);
}

var word = "hello";
var animals = ["cat", "dog", "bird"];
var salutation = "goodbye";
var target = ["sun", "moon"];
var greeting = []
greeter(word, animals);
greeter(salutation, target);
greeter(word, target);
function greeter(str, arr) {
    var counter;
    for(counter = 0; counter < arr.length; counter++) {
        console.log(str + " " + arr[counter])
    }
}

//functions should be flexible,reusable,independent
var testString = "hello world";
console.log(titleCase(testString));
console.log(titleCase("this is a title"));
function titleCase(str) {
    var strArray = str.split(" ");
    var counter;
    for (counter = 0; counter < strArray.length; counter++) {
        strArray[counter] = capitalize(strArray[counter]);
    }
    return strArray;
}

function capitalize(str) {
    var result = [];
    result[0] = str.charAt(0).toUpperCase();
    result[1] = str.substring(1);
    return (result.join(""));
}