var isBoss = confirm('are u a boss');
alert(isBoss);