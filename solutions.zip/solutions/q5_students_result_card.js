// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here

const results=()=>{
    const studentsList=[
        {name:'sai',subjects:[{subject:'Grammer',marks:89},{subject:'Accounts',marks:89}]},
        {name:'charan',subjects:[{subject:'Grammer',marks:78},{subject:'Accounts',marks:78}]},
        {name:'kalyani',subjects:[{subject:'Grammer',marks:67},{subject:'Accounts',marks:67}]},
        {name:'shravika',subjects:[{subject:'Grammer',marks:66},{subject:'Accounts',marks:89}]},
        {name:'supraja',subjects:[{subject:'Grammer',marks:78},{subject:'Accounts',marks:78}]},
        {name:'yesh',subjects:[{subject:'Grammer',marks:67},{subject:'Accounts',marks:89}]},
        {name:'ram',subjects:[{subject:'Grammer',marks:89},{subject:'Accounts',marks:67}]}
    ]
    const result=()=>
    studentsList.reduce((obj,item)=>{
    
        let percenRes=item.subjects.reduce(()=>{
            return (item.subjects[0].marks+item.subjects[1].marks)/item.subjects.length;
        }, {})
        console.log({ 'name':item.name,'percentage':percenRes});
    }, {})
    const finResult=result(studentsList);
    return finResult;
    }
    results();