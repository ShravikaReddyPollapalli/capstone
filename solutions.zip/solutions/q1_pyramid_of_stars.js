/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = (n) => {
     
       for (let i = 0; i < n; i++) { 
            var str = ''; 
            for (let j = 0; j < n-i; j++) { 
              str = str + ' '; 
            } 
            for (let k = 0; k <= i; k++) { 
              str = str + '* '; 
            } 
            console.log(str); 
          } 
        } 
   buildPyramid(6);

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
